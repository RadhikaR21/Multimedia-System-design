

Run the imageReader.java file and input in command line values with the imagepath as first parameter followed by the values of Y, U, V and Q as follows :

javac imageReader.java 
for compiling the java file and then run it as
 
java imageReader C:\Users\rradh\workspace\Multimedia\src\Image1.rgb 1 1 1 2  
